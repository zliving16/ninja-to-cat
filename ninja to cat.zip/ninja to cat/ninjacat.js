$(document).ready(function(){

     /* $('.categ').click(function() {
        console.log("clicked");
       
        $('.categ:dat-alt-src').change(function(){
            console.log('changer');
        
      });  */
    
       /*  $(this).attr('data-alt-src'));
        var src= $(this).attr('src');console.log(src);
        var altsrc= $(this).attr('data-alt-src');console.log(altsrc);
        $(this).attr("src", "data-alt-src");
        $("img").click(function(){
        // Change src attribute of image
        $(this).attr("src", "images/card-front.jpg");
    });    

 */

    $(".categ").click(function(){
    
    // Change src attribute of image
    var src=$(this).attr('src')
    var altsrc=$(this).attr('data-alt-src');
    $(this).attr("src", altsrc);
    $(this).attr("data-alt-src", src);
});  

$(".categ1").click(function(){
    var src=$(this).attr('src')
    var altsrc=$(this).attr('data-alt-src');
    $(this).attr("src", altsrc);
    $(this).attr("data-alt-src", src);
});   
$(".categ2").click(function(){
    var src=$(this).attr('src')
    var altsrc=$(this).attr('data-alt-src');
    $(this).attr("src", altsrc);
    $(this).attr("data-alt-src", src);
});   
$(".categ3").click(function(){
    var src=$(this).attr('src')
    var altsrc=$(this).attr('data-alt-src');
    $(this).attr("src", altsrc);
    $(this).attr("data-alt-src", src);
});   
$(".categ4").click(function(){
    var src=$(this).attr('src')
    var altsrc=$(this).attr('data-alt-src');
    $(this).attr("src", altsrc);
    $(this).attr("data-alt-src", src);
});   















});